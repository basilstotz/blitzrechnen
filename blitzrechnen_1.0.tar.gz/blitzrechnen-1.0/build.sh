#!/bin/sh
dpkg-buildpackage -uc -tc
