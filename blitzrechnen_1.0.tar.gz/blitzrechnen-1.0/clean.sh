#!/bin/sh
rm ../luegeloselaese_1.0*
