#!/bin/sh
rm ../blitzrechnen_1.0*
